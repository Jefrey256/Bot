const botv = "𝐕6 𝐅𝐢𝐧𝐚𝐥";

const menu = (prefix, isPremium, NomeDoBot, pushname, sender) => {
return `
┌─╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌─┐
┊       💛𝐁𝐄𝐌 𝐕𝐈𝐍𝐃𝐎 (𝐀)💛
└─╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌─┘    

╓╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║⋆💛ׁ͙̟̇𓈒·₊˚𝐔𝐬𝐮𝐚𝐫𝐢𝐨: ${pushname}
║⋆💛ׁ͙̟̇𓈒·₊˚𝐕𝐞𝐫𝐬𝐚̃𝐨: *${botv}*
║⋆💛ׁ͙̟̇𓈒·₊˚𝐁𝐨𝐭: *${NomeDoBot}*  
║⋆💛ׁ͙̟̇𓈒·₊˚𝐏𝐫𝐞𝐦𝐢𝐮𝐦: *${isPremium ? "✓" : "✘"}*  
┗╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯

╓┰╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║┋    ୨ 💛 𝐌𝐄𝚴𝐔𝐒💛 ୧
║┣╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯
║┃࣪╭★∻∹⋰⋰ ☆∻∹⋰⋰ ★∻∹⋰⋰
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *MenuDono*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *MenuCompleto*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *MenuAdm*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *MenuAtivar*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *MenuPremium*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *MenuEffect*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *MenuLogod*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *MenuMembro*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *MenuDown*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *MenuPlaqs*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *MenuFigs*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *MenuRpg*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *MenuHentai*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *MenuPorno*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *MenuInfo*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *MenuNews*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *MenuZoas*
║┖┴◆:*:◇:*:◆:*:◇:*:◆:*:◇:*💛:*
┗─︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪┛

╓┰╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║┋  ୨ 💛𝐌𝐄𝐌𝐁𝐑❍𝐒💛 ୧
║┣╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯
║┃࣪╭★∻∹⋰⋰ ☆∻∹⋰⋰ ★∻∹⋰⋰
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *Idiomas*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *Bug*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *Sugestao*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *Avalie*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *Moedas*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *Sticker*
║┖┴◆:*:◇:*:◆:*:◇:*:◆:*:◇:*💛:*
┗─︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪┛

╓┰╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║┋  ୨ 💛𝐓𝐀𝐊𝐄'𝐬💛 ୧
║┣╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯
║┃࣪╭★∻∹⋰⋰ ☆∻∹⋰⋰ ★∻∹⋰⋰
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *Rgtake*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *RnTake*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *Take*
║┖┴◆:*:◇:*:◆:*:◇:*:◆:*:◇:*💛:*
┗─︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪┛

╓┰╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║┋ ୨ 💛𝐃❍𝐖𝐍𝐋❍𝐀𝐃'𝐬💛 ୧
║┣╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯
║┃࣪╭★∻∹⋰⋰ ☆∻∹⋰⋰ ★∻∹⋰⋰
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *Play*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *Play2*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *PlayMP3*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *PlayStore*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *YtSearch*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *YtMp3*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *YtMp4*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *TikTok*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *Instagram*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *Insta_Audio*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *Insta_video*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *FaceBook*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *Amazon*
║┖┴◆:*:◇:*:◆:*:◇:*:◆:*:◇:*💛:*
┗─︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪┛

╓┰╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║┋  ୨ 💛𝐍❍𝐓𝐈𝐂𝐈𝐀'𝐬💛 ୧
║┣╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯
║┃࣪╭★∻∹⋰⋰ ☆∻∹⋰⋰ ★∻∹⋰⋰
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *Globo*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *Poder360*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *JovemPan*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *Uol*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *Estadao*
║┖┴◆:*:◇:*:◆:*:◇:*:◆:*:◇:*💛:*
┗─︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪┛

╓┰╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║┋୨ 💛𝐃𝐄𝐌𝐀𝐈𝐒 𝐂𝐌𝐃'𝐬💛 ୧
║┣╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯
║┃࣪╭★∻∹⋰⋰ ☆∻∹⋰⋰ ★∻∹⋰⋰
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *Ping*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *Atividades*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *Rankativo*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *Checkativo*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *Ranklevel*
║┖┴◆:*:◇:*:◆:*:◇:*:◆:*:◇:*💛:*
┗─︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪┛

╓┰╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║┋୨ 💛𝐀𝐋𝐄𝐀𝐓❍𝐑𝐈❍'𝐬💛 ୧
║┣╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯
║┃࣪╭★∻∹⋰⋰ ☆∻∹⋰⋰ ★∻∹⋰⋰
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *Esporte_Noticias*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *Celular*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *Gtts*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *TagMe*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *Emoji*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *EmojiMix*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *Tabela*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *ConselhoBiblico*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *Perfil*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *Calcular*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *Fazernick*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *Signo*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *MetaDinha*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *ToMp3*
║┖┴◆:*:◇:*:◆:*:◇:*:◆:*:◇:*💛:*
┗─︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪┛
`;
};

exports.menu = menu;
const adms = (prefix, isPremium, NomeDoBot, pushname, sender) => { 
return `┌─╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌─┐
┊       💛𝐁𝐄𝐌 𝐕𝐈𝐍𝐃𝐎 (𝐀)💛
└─╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌─┘    

╓╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║⋆💛ׁ͙̟̇𓈒·₊˚𝐔𝐬𝐮𝐚𝐫𝐢𝐨: ${pushname}
║⋆💛ׁ͙̟̇𓈒·₊˚𝐕𝐞𝐫𝐬𝐚̃𝐨: *${botv}*
║⋆💛ׁ͙̟̇𓈒·₊˚𝐁𝐨𝐭: *${NomeDoBot}*  
║⋆💛ׁ͙̟̇𓈒·₊˚𝐏𝐫𝐞𝐦𝐢𝐮𝐦: *${isPremium ? "✓" : "✘"}*  
┗╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯

╓┰╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║┋ ୨ 💛𝐌𝐄𝐍𝐔 𝐀𝐃𝐌𝐈𝐍'𝐬💛 ୧
║┣╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯
║┃࣪╭★∻∹⋰⋰ ☆∻∹⋰⋰ ★∻∹⋰⋰
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}MenuAtivar
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}so_adm 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}mute
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}desmute
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}listanegra (𝙽𝙼𝚁) 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}tirardalista (𝙽𝙼𝚁) 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}listanegraG (𝙽𝙼𝚁) 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}tirardalistaG (𝙽𝙼𝚁) 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Kick [@] (𝙿-𝚁𝙼𝚅) 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Ban (𝙱𝙰𝙽𝙸𝚁-𝙿𝚂𝚂) 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Promover [@] (𝙿𝚁𝙼𝚅-𝙰𝙳𝙼) 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Rebaixar [@] (𝚁𝙱𝚇-𝙰𝙳𝙼) 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Totag (𝙼𝙴𝙽𝙲-𝙰𝙻𝙶𝙾) 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Grupo 𝙵/𝙰 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Status 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Limpar (𝙻𝙸𝙼𝙿𝙰-𝙶𝙿) 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Atividades (𝙳𝙾-𝙶𝙿) 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Linkgp 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Grupoinfo 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Hidetag (𝚃𝚇𝚃) 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Marcar (𝙼𝙰𝚁𝙲𝙰 𝙶𝚁𝙻) 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Marcar2 (𝙼𝙰𝚁𝙲𝙰 𝚆𝙰) 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Antipalavra 1 / 0 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Descgp (𝚃𝚇𝚃) 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Nomegp (𝙽𝙰𝙼𝙴) 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Criartabela (𝙳𝙶𝚃-𝙰𝙻𝙶𝙾) 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Tabelagp 
║┖┴◆:*:◇:*:◆:*:◇:*:◆:*:◇:*💛:*
┗─︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪┛
`;
};

exports.adms = adms;

const menudono = (prefix, isPremium, NomeDoBot, pushname, sender) => {

return `┌─╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌─┐
┊       💛𝐁𝐄𝐌 𝐕𝐈𝐍𝐃𝐎 (𝐀)💛
└─╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌─┘    

╓╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║⋆💛ׁ͙̟̇𓈒·₊˚𝐔𝐬𝐮𝐚𝐫𝐢𝐨: ${pushname}
║⋆💛ׁ͙̟̇𓈒·₊˚𝐕𝐞𝐫𝐬𝐚̃𝐨: *${botv}*
║⋆💛ׁ͙̟̇𓈒·₊˚𝐁𝐨𝐭: *${NomeDoBot}*  
║⋆💛ׁ͙̟̇𓈒·₊˚𝐏𝐫𝐞𝐦𝐢𝐮𝐦: *${isPremium ? "✓" : "✘"}*  
┗╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯

╓┰╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║┋୨ 💛𝐌𝐄𝐍𝐔 𝐃𝐎𝐍𝐎'𝐬💛 ୧
║┣╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯
║┃࣪╭★∻∹⋰⋰ ☆∻∹⋰⋰ ★∻∹⋰⋰
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}ativacoes_dono
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Serpremium
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Listagp 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Bangp
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Unbangp 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Blockcmd (cmd)
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Unblockcmd (cmd)
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Legenda_estrangeiro (msg) 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Legendabv / Legendabv2 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Legendasaiu / Legendasaiu2 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Fundobemvindo (IMG) 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Fundosaiu (IMG)    
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Antipalavrão 1/0    
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Antiligar 1/0       
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Addpalavra (palavrão) 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Delpalavra (palavrão) 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Ativo
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Ausente (motivo)     
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Delpremium @(marca) 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Addpremium @(marca)  
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Clonar [@]   
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Fotobot (IMG)
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Descriçãogp (TXT)    
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Block / Unblock [@]  
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Setprefix (novo)    
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Bcgp (mensagem geral)
║┖┴◆:*:◇:*:◆:*:◇:*:◆:*:◇:*💛:*
┗─︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪┛
`;

};

exports.menudono = menudono;

const menulogos = (prefix, isPremium, NomeDoBot, pushname, sender) => {
return `┌─╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌─┐
┊       💛𝐁𝐄𝐌 𝐕𝐈𝐍𝐃𝐎 (𝐀)💛
└─╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌─┘    

╓╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║⋆💛ׁ͙̟̇𓈒·₊˚𝐔𝐬𝐮𝐚𝐫𝐢𝐨: ${pushname}
║⋆💛ׁ͙̟̇𓈒·₊˚𝐕𝐞𝐫𝐬𝐚̃𝐨: *${botv}*
║⋆💛ׁ͙̟̇𓈒·₊˚𝐁𝐨𝐭: *${NomeDoBot}*  
║⋆💛ׁ͙̟̇𓈒·₊˚𝐏𝐫𝐞𝐦𝐢𝐮𝐦: *${isPremium ? "✓" : "✘"}*  
┗╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯

╓┰╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║┋୨ 💛𝐌𝐄𝐍𝐔 𝐋𝐎𝐆𝐎'𝐬💛 ୧
║┣╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯
║┃࣪╭★∻∹⋰⋰ ☆∻∹⋰⋰ ★∻∹⋰⋰
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}logos1 (txt) 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Comporn (txt / txt) 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Glitch (txt / txt) 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Glitch3 (txt / txt) 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Grafity (txt - txt) 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Space (txt / txt) 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Marvel (txt / txt) 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Stone (txt / txt) 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Steel (txt / txt) 
║┖┴◆:*:◇:*:◆:*:◇:*:◆:*:◇:*💛:*
┗─︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪┛
`;
};

exports.menulogos = menulogos;

const alteradores = (prefix, isPremium, NomeDoBot, pushname, sender) => {

return`┌─╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌─┐
┊       💛𝐁𝐄𝐌 𝐕𝐈𝐍𝐃𝐎 (𝐀)💛
└─╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌─┘    

╓╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║⋆💛ׁ͙̟̇𓈒·₊˚𝐔𝐬𝐮𝐚𝐫𝐢𝐨: ${pushname}
║⋆💛ׁ͙̟̇𓈒·₊˚𝐕𝐞𝐫𝐬𝐚̃𝐨: *${botv}*
║⋆💛ׁ͙̟̇𓈒·₊˚𝐁𝐨𝐭: *${NomeDoBot}*  
║⋆💛ׁ͙̟̇𓈒·₊˚𝐏𝐫𝐞𝐦𝐢𝐮𝐦: *${isPremium ? "✓" : "✘"}*  
┗╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯

╓┰╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║┋୨ 💛𝐀𝐋𝐓𝐄𝐑𝐀𝐃𝐎𝐑𝐄'𝐬💛 ୧
║┣╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯
║┃࣪╭★∻∹⋰⋰ ☆∻∹⋰⋰ ★∻∹⋰⋰
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Videolento (marca) 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Videorapido (marca) 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Videocontrario (marca) 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Audiolento (marca) 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Audiorapido (marca) 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Grave (marca) 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Grave2 (marca) 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Esquilo (marca) 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Estourar (marca) 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Bass (marca) 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Bass2 (marca) 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Vozmenino (marca) 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Audioreverse (marca)
║┖┴◆:*:◇:*:◆:*:◇:*:◆:*:◇:*💛:*
┗─︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪┛
`;
};

exports.alteradores = alteradores;

const menuprem = (prefix, isPremium, NomeDoBot, pushname, sender) => { 
return `┌─╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌─┐
┊       💛𝐁𝐄𝐌 𝐕𝐈𝐍𝐃𝐎 (𝐀)💛
└─╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌─┘    

╓╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║⋆💛ׁ͙̟̇𓈒·₊˚𝐔𝐬𝐮𝐚𝐫𝐢𝐨: ${pushname}
║⋆💛ׁ͙̟̇𓈒·₊˚𝐕𝐞𝐫𝐬𝐚̃𝐨: *${botv}*
║⋆💛ׁ͙̟̇𓈒·₊˚𝐁𝐨𝐭: *${NomeDoBot}*  
║⋆💛ׁ͙̟̇𓈒·₊˚𝐏𝐫𝐞𝐦𝐢𝐮𝐦: *${isPremium ? "✓" : "✘"}*  
┗╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯

╓┰╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║┋୨ 💛𝐌𝐄𝐍𝐔 𝐕𝐈𝐏'𝐬💛 ୧
║┣╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯
║┃࣪╭★∻∹⋰⋰ ☆∻∹⋰⋰ ★∻∹⋰⋰
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}puxahtml (𝚂𝙸𝚃𝙴)
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}premiumfrase
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}premiumqr (𝚃𝚇𝚃)
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}premiumheaders 
║┖┴◆:*:◇:*:◆:*:◇:*:◆:*:◇:*💛:*
┗─︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪┛`;
};

exports.menuprem = menuprem;

const brincadeiras = (prefix, isPremium, NomeDoBot, pushname, sender) => {
return `┌─╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌─┐
┊       💛𝐁𝐄𝐌 𝐕𝐈𝐍𝐃𝐎 (𝐀)💛
└─╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌─┘    

╓╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║⋆💛ׁ͙̟̇𓈒·₊˚𝐔𝐬𝐮𝐚𝐫𝐢𝐨: ${pushname}
║⋆💛ׁ͙̟̇𓈒·₊˚𝐕𝐞𝐫𝐬𝐚̃𝐨: *${botv}*
║⋆💛ׁ͙̟̇𓈒·₊˚𝐁𝐨𝐭: *${NomeDoBot}*  
║⋆💛ׁ͙̟̇𓈒·₊˚𝐏𝐫𝐞𝐦𝐢𝐮𝐦: *${isPremium ? "✓" : "✘"}*  
┗╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯

╓┰╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║┋ ୨ 💛𝐉𝐎𝐆𝐔𝐈𝐍𝐇𝐎'𝐬💛 ୧
║┣╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯
║┃࣪╭★∻∹⋰⋰ ☆∻∹⋰⋰ ★∻∹⋰⋰
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}iniciar_forca 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}ppt  
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}jogodavelha  @
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}cassino      
║┖┴◆:*:◇:*:◆:*:◇:*:◆:*:◇:*💛:*
┗─︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪┛

╓┰╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║┋  ୨ 💛𝐁𝐑𝐈𝐍𝐂𝐀𝐃𝐄𝐈𝐑𝐀𝐒'𝐬💛 ୧
║┣╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯
║┃࣪╭★∻∹⋰⋰ ☆∻∹⋰⋰ ★∻∹⋰⋰
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Gay (marca)         
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Feio (marca)        
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Corno (marca)       
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Vesgo (marca)       
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Bebado (marca)      
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Gostoso (marca)     
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Gostosa (marca)     
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Beijo (marca)       
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Matar (marca)       
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Tapa (marca)        
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Chute (marca)       
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Dogolpe (marca)     
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Nazista (marca)     
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Chance (texto)      
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Casal               
║┖┴◆:*:◇:*:◆:*:◇:*:◆:*:◇:*💛:*
┗─︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪┛

╓┰╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║┋୨ 💛𝐑𝐀𝐍𝐊𝐈𝐍𝐆'𝐬💛 ୧
║┣╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯
║┃࣪╭★∻∹⋰⋰ ☆∻∹⋰⋰ ★∻∹⋰⋰
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Rankgay             
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Rankgado            
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Rankcorno           
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Rankgostoso         
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Rankgostosa         
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Ranknazista         
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Rankotakus          
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Rankpau
║┖┴◆:*:◇:*:◆:*:◇:*:◆:*:◇:*💛:*
┗─︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪┛
`;
};

exports.brincadeiras = brincadeiras;


const efeitos = (prefix, isPremium, NomeDoBot, pushname, sender) => {

return `┌─╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌─┐
┊       💛𝐁𝐄𝐌 𝐕𝐈𝐍𝐃𝐎 (𝐀)💛
└─╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌─┘    

╓╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║⋆💛ׁ͙̟̇𓈒·₊˚𝐔𝐬𝐮𝐚𝐫𝐢𝐨: ${pushname}
║⋆💛ׁ͙̟̇𓈒·₊˚𝐕𝐞𝐫𝐬𝐚̃𝐨: *${botv}*
║⋆💛ׁ͙̟̇𓈒·₊˚𝐁𝐨𝐭: *${NomeDoBot}*  
║⋆💛ׁ͙̟̇𓈒·₊˚𝐏𝐫𝐞𝐦𝐢𝐮𝐦: *${isPremium ? "✓" : "✘"}*  
┗╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯

╓┰╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║┋  ୨ 💛𝐄𝐅𝐄𝐈𝐓❍𝐒💛 ୧
║┣╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯
║┃࣪╭★∻∹⋰⋰ ☆∻∹⋰⋰ ★∻∹⋰⋰
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}legenda (marcar)-(img) 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}procurado (marcar)-(img) 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}hitler (marcar)-(img) 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}preso (marcar)-(img) 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}lixo (marcar)-(img) 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}deletem (marcar)-(img) 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}morto (marcar)-(img) 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}lgbt (marcar)-(img) 
║┖┴◆:*:◇:*:◆:*:◇:*:◆:*:◇:*💛:*
┗─︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪┛`;
};

exports.efeitos = efeitos;

const menurpg = (prefix, isPremium, NomeDoBot, pushname, sender) => { 

return `┌─╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌─┐
┊       💛𝐁𝐄𝐌 𝐕𝐈𝐍𝐃𝐎 (𝐀)💛
└─╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌─┘    

╓╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║⋆💛ׁ͙̟̇𓈒·₊˚𝐔𝐬𝐮𝐚𝐫𝐢𝐨: ${pushname}
║⋆💛ׁ͙̟̇𓈒·₊˚𝐕𝐞𝐫𝐬𝐚̃𝐨: *${botv}*
║⋆💛ׁ͙̟̇𓈒·₊˚𝐁𝐨𝐭: *${NomeDoBot}*  
║⋆💛ׁ͙̟̇𓈒·₊˚𝐏𝐫𝐞𝐦𝐢𝐮𝐦: *${isPremium ? "✓" : "✘"}*  
┗╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯

╓┰╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║┋୨ 💛𝐂𝐎𝐍𝐓𝐀/𝐒𝐓𝐀𝐓𝐔𝐒💛 ୧
║┣╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯
║┃࣪╭★∻∹⋰⋰ ☆∻∹⋰⋰ ★∻∹⋰⋰
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *𝐑𝐞𝐠𝐢𝐬𝐭𝐫𝐚𝐫*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *𝐌𝐞𝐮𝐄𝐬𝐭𝐚𝐝𝐨*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *𝐒𝐭𝐚𝐭𝐮𝐬*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *𝐒𝐚𝐥𝐝𝐨*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *𝐒𝐨𝐫𝐭𝐞𝐃𝐨𝐃𝐢𝐚*
║┖┴◆:*:◇:*:◆:*:◇:*:◆:*:◇:*💛:*
┗─︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪┛

╓┰╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║┋ ୨ 💛𝐕𝐈𝐃𝐀 & 𝐑𝐎𝐓𝐈𝐍𝐀💛 ୧
║┣╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯
║┃࣪╭★∻∹⋰⋰ ☆∻∹⋰⋰ ★∻∹⋰⋰
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *𝐀𝐥𝐢𝐦𝐞𝐧𝐭𝐚𝐫*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *𝐃𝐨𝐫𝐦𝐢𝐫*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *𝐁𝐚𝐧𝐡𝐨*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *𝐁𝐫𝐢𝐧𝐜𝐚𝐫*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *𝐂𝐨𝐦𝐞𝐫*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *𝐂𝐮𝐫𝐚𝐫*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *𝐂𝐮𝐫𝐚*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *𝐂𝐨𝐥𝐞𝐭𝐚𝐫*
║┖┴◆:*:◇:*:◆:*:◇:*:◆:*:◇:*💛:*
┗─︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪┛

╓┰╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║┋୨ 💛𝐓𝐑𝐀𝐁𝐀𝐋𝐇𝐎 & 𝐃𝐈𝐍𝐇𝐄𝐈𝐑𝐎💛 ୧
║┣╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯
║┃࣪╭★∻∹⋰⋰ ☆∻∹⋰⋰ ★∻∹⋰⋰
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *𝐄𝐬𝐜𝐨𝐥𝐡𝐞𝐫𝐓𝐫𝐚𝐛𝐚𝐥𝐡𝐨 [𝙽𝚘𝚖𝚎]*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *𝐓𝐫𝐚𝐛𝐚𝐥𝐡𝐚𝐫*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *𝐕𝐞𝐫𝐓𝐫𝐚𝐛𝐚𝐥𝐡𝐨*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *𝐃𝐞𝐦𝐢𝐭𝐢𝐫*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *𝐅𝐞𝐫𝐢𝐚𝐬*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *𝐑𝐨𝐮𝐛𝐚𝐫*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *𝐃𝐞𝐩𝐨𝐬𝐢𝐭𝐚𝐫 [𝚅𝚊𝚕𝚘𝚛]*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *𝐒𝐚𝐜𝐚𝐫 [𝚅𝚊𝚕𝚘𝚛]*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *𝐃𝐨𝐚𝐫 [𝙿𝚎𝚜𝚜𝚘𝚊] [𝚅𝚊𝚕𝚘𝚛]*
║┖┴◆:*:◇:*:◆:*:◇:*:◆:*:◇:*💛:*
┗─︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪┛

╓┰╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║┋୨ 💛𝐈𝐍𝐕𝐄𝐍𝐓𝐀𝐑𝐈𝐎 & 𝐋𝐎𝐉𝐀💛 ୧
║┣╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯
║┃࣪╭★∻∹⋰⋰ ☆∻∹⋰⋰ ★∻∹⋰⋰
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}inventario *𝐈𝐧𝐯𝐞𝐧𝐭𝐚𝐫𝐢𝐨*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *𝐔𝐬𝐚𝐫𝐈𝐭𝐞𝐦*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *𝐄𝐪𝐮𝐢𝐩𝐚𝐫 [𝙸𝚝𝚎𝚖]*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *𝐋𝐨𝐣𝐚*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *𝐂𝐨𝐦𝐩𝐫𝐚𝐫 [𝙸𝚝𝚎𝚖]*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *𝐌𝐞𝐫𝐜𝐚𝐝𝐨*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *𝐋𝐞𝐢𝐥𝐚̃𝐨*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *𝐋𝐚𝐧𝐜𝐞 [𝚅𝚊𝚕𝚘𝚛]*
║┖┴◆:*:◇:*:◆:*:◇:*:◆:*:◇:*💛:*
┗─︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪┛

╓┰╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║┋୨ 💛𝐂𝐀𝐒𝐀 & 𝐅𝐀𝐌𝐈𝐋𝐈𝐀💛 ୧
║┣╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯
║┃࣪╭★∻∹⋰⋰ ☆∻∹⋰⋰ ★∻∹⋰⋰
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *𝐂𝐨𝐦𝐩𝐫𝐚𝐫𝐂𝐚𝐬𝐚 [𝙽𝚘𝚖𝚎]*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *𝐌𝐢𝐧𝐡𝐚𝐂𝐚𝐬𝐚*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *𝐂𝐚𝐬𝐚𝐫 [@𝙿𝚎𝚜𝚜𝚘𝚊]*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *𝐀𝐜𝐞𝐢𝐭𝐚𝐫𝐂𝐚𝐬𝐚𝐦𝐞𝐧𝐭𝐨*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *𝐃𝐢𝐯𝐨𝐫𝐜𝐢𝐨*
║┖┴◆:*:◇:*:◆:*:◇:*:◆:*:◇:*💛:*
┗─︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪┛

╓┰╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║┋      ୨ 💛𝐏𝐄𝐓'𝐒💛 ୧
║┣╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯
║┃࣪╭★∻∹⋰⋰ ☆∻∹⋰⋰ ★∻∹⋰⋰
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *𝐂𝐫𝐢𝐚𝐫𝐏𝐞𝐭 [𝙽𝚘𝚖𝚎][𝚃𝚒𝚙𝚘]*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *𝐒𝐭𝐚𝐭𝐮𝐬𝐏𝐞𝐭*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *𝐀𝐥𝐢𝐦𝐞𝐧𝐭𝐚𝐫𝐏𝐞𝐭*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *𝐓𝐫𝐞𝐢𝐧𝐚𝐫𝐏𝐞𝐭*
║┖┴◆:*:◇:*:◆:*:◇:*:◆:*:◇:*💛:*
┗─︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪┛

╓┰╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║┋୨ 💛𝐀𝐕𝐄𝐍𝐓𝐔𝐑𝐀𝐒 & 𝐑𝐏𝐆💛 ୧
║┣╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯
║┃࣪╭★∻∹⋰⋰ ☆∻∹⋰⋰ ★∻∹⋰⋰
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *𝐄𝐱𝐩𝐥𝐨𝐫𝐚𝐫*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *𝐂𝐚𝐜𝐚𝐨𝐓𝐞𝐬𝐨𝐮𝐫𝐨*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *𝐃𝐞𝐬𝐚𝐟𝐢𝐨𝐬*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *𝐂𝐨𝐧𝐪𝐮𝐢𝐬𝐭𝐚𝐬*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *𝐌𝐢𝐬𝐬𝐨̃𝐞𝐬*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *𝐑𝐞𝐧𝐚𝐬𝐜𝐞𝐫*
║┖┴◆:*:◇:*:◆:*:◇:*:◆:*:◇:*💛:*
┗─︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪┛

╓┰╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║┋୨ 💛𝐂𝐑𝐀𝐅𝐓 & 𝐄𝐕𝐎𝐋𝐔𝐂̧𝐀̃𝐎💛 ୧
║┣╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯
║┃࣪╭★∻∹⋰⋰ ☆∻∹⋰⋰ ★∻∹⋰⋰
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *𝐂𝐫𝐚𝐟𝐭 [𝙸𝚝𝚎𝚖]*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *𝐒𝐮𝐛𝐢𝐫𝐍𝐢𝐯𝐞𝐥*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *𝐄𝐯𝐞𝐧𝐭𝐨*
║┖┴◆:*:◇:*:◆:*:◇:*:◆:*:◇:*💛:*
┗─︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪┛

╓┰╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║┋  ୨ 💛𝐑𝐀𝐍𝐊𝐈𝐍𝐆'𝐬💛 ୧
║┣╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯
║┃࣪╭★∻∹⋰⋰ ☆∻∹⋰⋰ ★∻∹⋰⋰
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *𝐑𝐚𝐧𝐤𝐢𝐧𝐠*
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix} *𝐑𝐚𝐤𝐢𝐧𝐠𝐗𝐩*
║┖┴◆:*:◇:*:◆:*:◇:*:◆:*:◇:*💛:*
┗─︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪┛`;
};
exports.menurpg = menurpg;

const menuativacao = (prefix, isPremium, NomeDoBot, pushname, sender) => { 

return `┌─╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌─┐
┊       💛𝐁𝐄𝐌 𝐕𝐈𝐍𝐃𝐎 (𝐀)💛
└─╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌─┘    

╓╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║⋆💛ׁ͙̟̇𓈒·₊˚𝐔𝐬𝐮𝐚𝐫𝐢𝐨: ${pushname}
║⋆💛ׁ͙̟̇𓈒·₊˚𝐕𝐞𝐫𝐬𝐚̃𝐨: *${botv}*
║⋆💛ׁ͙̟̇𓈒·₊˚𝐁𝐨𝐭: *${NomeDoBot}*  
║⋆💛ׁ͙̟̇𓈒·₊˚𝐏𝐫𝐞𝐦𝐢𝐮𝐦: *${isPremium ? "✓" : "✘"}*  
┗╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯

╓┰╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║┋  ୨ 💛𝐀𝐓𝐈𝐕𝐀𝐂𝐀❍💛 ୧
║┣╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯
║┃࣪╭★∻∹⋰⋰ ☆∻∹⋰⋰ ★∻∹⋰⋰
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}antifake 1 / 0
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}anticatalogo 1 / 0
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}antiloc 1 / 0
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}x9 1 / 0
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}x9visuunica 1 / 0
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}modobrincadeira 1 / 0
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}antilinkgp 1 / 0
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}bemvindo 1 / 0
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}bemvindo2 1 / 0
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}leveling 1 / 0
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}antivideo 1 / 0
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}antiimg 1 / 0
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}antiaudio 1 / 0
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}antidoc 1 / 0
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}antictt 1 / 0
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}antisticker 1 / 0
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}autofigu 1 / 0
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}simih 1 / 0
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}simih2 1 / 0
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}autorepo 1 / 0
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}antipalavrao 1 / 0
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}nsfw 1 / 0
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}So_Adm
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}recolherlink
║┖┴◆:*:◇:*:◆:*:◇:*:◆:*:◇:*💛:*
┗─︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪┛

╓┰╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║┋  ୨ 💛𝐃𝐎𝐍❍𝐒💛 ୧
║┣╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯
║┃࣪╭★∻∹⋰⋰ ☆∻∹⋰⋰ ★∻∹⋰⋰
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}antiligar 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}visualizarmsg
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}console
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}antipv
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}antipv2
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}audio-menu
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}verificado-global
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}botoff
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}boton
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}So_Adm
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}recolherlink
║┖┴◆:*:◇:*:◆:*:◇:*:◆:*:◇:*💛:*
┗─︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪┛`;
};

exports.menuativacao = menuativacao;

const menubsc = (prefix, isPremium, NomeDoBot, pushname, sender) => {

return `┌─╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌─┐
┊       💛𝐁𝐄𝐌 𝐕𝐈𝐍𝐃𝐎 (𝐀)💛
└─╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌─┘    

╓╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║⋆💛ׁ͙̟̇𓈒·₊˚𝐔𝐬𝐮𝐚𝐫𝐢𝐨: ${pushname}
║⋆💛ׁ͙̟̇𓈒·₊˚𝐕𝐞𝐫𝐬𝐚̃𝐨: *${botv}*
║⋆💛ׁ͙̟̇𓈒·₊˚𝐁𝐨𝐭: *${NomeDoBot}*  
║⋆💛ׁ͙̟̇𓈒·₊˚𝐏𝐫𝐞𝐦𝐢𝐮𝐦: *${isPremium ? "✓" : "✘"}*  
┗╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯

╓┰╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║┋   ୨ 💛𝐁𝐀𝐒𝐈𝐂❍𝐒💛 ୧
║┣╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯
║┃࣪╭★∻∹⋰⋰ ☆∻∹⋰⋰ ★∻∹⋰⋰
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}esporte_noticias 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}celular  
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}gtts 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}tagme
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}emoji
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}emojimix 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}tabela   
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}conselhobiblico  
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}perfil   
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}calcular 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}fazernick
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}bot  
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}signo
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}metadinha
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}tomp3   
║┖┴◆:*:◇:*:◆:*:◇:*:◆:*:◇:*💛:*
┗─︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪┛`;
};

exports.menubsc = menubsc;

const menufigu = (prefix, isPremium, NomeDoBot, pushname, sender) => {

return `┌─╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌─┐
┊       💛𝐁𝐄𝐌 𝐕𝐈𝐍𝐃𝐎 (𝐀)💛
└─╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌─┘    

╓╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║⋆💛ׁ͙̟̇𓈒·₊˚𝐔𝐬𝐮𝐚𝐫𝐢𝐨: ${pushname}
║⋆💛ׁ͙̟̇𓈒·₊˚𝐕𝐞𝐫𝐬𝐚̃𝐨: *${botv}*
║⋆💛ׁ͙̟̇𓈒·₊˚𝐁𝐨𝐭: *${NomeDoBot}*  
║⋆💛ׁ͙̟̇𓈒·₊˚𝐏𝐫𝐞𝐦𝐢𝐮𝐦: *${isPremium ? "✓" : "✘"}*  
┗╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯

╓┰╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║┋   ୨ 💛𝐀𝐓𝐓𝐏'𝐬💛 ୧
║┣╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯
║┃࣪╭★∻∹⋰⋰ ☆∻∹⋰⋰ ★∻∹⋰⋰
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}attp     
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}attp2    
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}fsticker 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}sticker  
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}toimg    
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}togif    
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}roubar   
║┖┴◆:*:◇:*:◆:*:◇:*:◆:*:◇:*💛:*
┗─︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪┛

╓┰╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║┋ ୨ 💛𝐅𝐈𝐆𝐔𝐑𝐈𝐍𝐇𝐀𝐒💛 ୧
║┣╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯
║┃࣪╭★∻∹⋰⋰ ☆∻∹⋰⋰ ★∻∹⋰⋰
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}figu-engracada(𝚀𝚗𝚝𝚍)
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}figu-animais  (𝚀𝚗𝚝𝚍)
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}figu-coreana (𝚀𝚗𝚝𝚍)
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}figu-anime  (𝚀𝚗𝚝𝚍)
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}figu-roblox  (𝚀𝚗𝚝𝚍)
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}figu-flork   (𝚀𝚗𝚝𝚍)
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}figu-desenho (𝚀𝚗𝚝𝚍)
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}figu-raiva (𝚀𝚗𝚝𝚍)
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}figu-random (𝚀𝚗𝚝𝚍)
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}figu-meme (𝚀𝚗𝚝𝚍)
║┖┴◆:*:◇:*:◆:*:◇:*:◆:*:◇:*💛:*
┗─︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪┛`;
};

exports.menufigu = menufigu;


const menuplaq = (prefix, isPremium, NomeDoBot, pushname, sender) => {

return `┌─╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌─┐
┊       💛𝐁𝐄𝐌 𝐕𝐈𝐍𝐃𝐎 (𝐀)💛
└─╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌─┘    
╓╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║⋆💛ׁ͙̟̇𓈒·₊˚𝐔𝐬𝐮𝐚𝐫𝐢𝐨: ${pushname}
║⋆💛ׁ͙̟̇𓈒·₊˚𝐕𝐞𝐫𝐬𝐚̃𝐨: *${botv}*
║⋆💛ׁ͙̟̇𓈒·₊˚𝐁𝐨𝐭: *${NomeDoBot}*  
║⋆💛ׁ͙̟̇𓈒·₊˚𝐏𝐫𝐞𝐦𝐢𝐮𝐦: *${isPremium ? "✓" : "✘"}*  
┗╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯

╓┰╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║┋  ୨ 💛𝐏𝐋𝐀𝐐𝐔𝐈𝐍𝐇𝐀𝐒💛 ୧
║┣╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯
║┃࣪╭★∻∹⋰⋰ ☆∻∹⋰⋰ ★∻∹⋰⋰
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}plaq  (𝚃𝚇𝚃)
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}plaq1 (𝚃𝚇𝚃)
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}plaq2 (𝚃𝚇𝚃)
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}plaq3 (𝚃𝚇𝚃)
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}plaq4 (𝚃𝚇𝚃)
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}plaq5 (𝚃𝚇𝚃)
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}plaq6 (𝚃𝚇𝚃)
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}plaq7 (𝚃𝚇𝚃)
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}plaq8 (𝚃𝚇𝚃)
║┖┴◆:*:◇:*:◆:*:◇:*:◆:*:◇:*💛:*
┗─︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪┛`;
};

exports.menuplaq = menuplaq;

const menuporn = (prefix, isPremium, NomeDoBot, pushname, sender) => {

return `┌─╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌─┐
┊       💛𝐁𝐄𝐌 𝐕𝐈𝐍𝐃𝐎 (𝐀)💛
└─╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌─┘    

╓╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║⋆💛ׁ͙̟̇𓈒·₊˚𝐔𝐬𝐮𝐚𝐫𝐢𝐨: ${pushname}
║⋆💛ׁ͙̟̇𓈒·₊˚𝐕𝐞𝐫𝐬𝐚̃𝐨: *${botv}*
║⋆💛ׁ͙̟̇𓈒·₊˚𝐁𝐨𝐭: *${NomeDoBot}*  
║⋆💛ׁ͙̟̇𓈒·₊˚𝐏𝐫𝐞𝐦𝐢𝐮𝐦: *${isPremium ? "✓" : "✘"}*  
┗╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯

╓┰╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║┋   ୨ 💛𝐏𝐎𝐑𝐍❍𝐒💛 ୧
║┣╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯
║┃࣪╭★∻∹⋰⋰ ☆∻∹⋰⋰ ★∻∹⋰⋰
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}xvideosrc
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}pornovid
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}onlyfans
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}amador
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}egirlvideo
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}aline
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}alinefx
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}alycia
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}amiichan
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}aninha
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}belle
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}brenda
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}camila
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}carniello
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}celestine
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}clowniac
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}feh
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}giovanna
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}gotica
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}isa
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}isadora
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}lay
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}leticia
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}marina
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}maru
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}meladinha
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}nath
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}nega
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}polonesa
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}princesa
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}victoria
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}rute
║┖┴◆:*:◇:*:◆:*:◇:*:◆:*:◇:*💛:*
┗─︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪┛`;
};

exports.menuporn = menuporn;

const menuinfo = (prefix, isPremium, NomeDoBot, pushname, sender) => {

return `┌─╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌─┐
┊       💛𝐁𝐄𝐌 𝐕𝐈𝐍𝐃𝐎 (𝐀)💛
└─╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌─┘    

╓╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║⋆💛ׁ͙̟̇𓈒·₊˚𝐔𝐬𝐮𝐚𝐫𝐢𝐨: ${pushname}
║⋆💛ׁ͙̟̇𓈒·₊˚𝐕𝐞𝐫𝐬𝐚̃𝐨: *${botv}*
║⋆💛ׁ͙̟̇𓈒·₊˚𝐁𝐨𝐭: *${NomeDoBot}*  
║⋆💛ׁ͙̟̇𓈒·₊˚𝐏𝐫𝐞𝐦𝐢𝐮𝐦: *${isPremium ? "✓" : "✘"}*  
┗╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯

╓┰╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║┋   ୨ 💛𝐈𝐍𝐅❍𝐒💛 ୧
║┣╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯
║┃࣪╭★∻∹⋰⋰ ☆∻∹⋰⋰ ★∻∹⋰⋰
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}infoAluguel
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}infopremium
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}infoforca
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Infoduelo
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Infotransmitir
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}InfoMultiPrefixo
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}InfoBemvindo
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Infopalavrão
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Infolistanegra
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Infobancarac
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Infovotação
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}InfoBanghost
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}Infosorteio 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}InfoAnotação
║┖┴◆:*:◇:*:◆:*:◇:*:◆:*:◇:*💛:*
┗─︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪┛`;
};

exports.menuinfo = menuinfo;

const menudown = (prefix, isPremium, NomeDoBot, pushname, sender) => {

return `┌─╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌─┐
┊       💛𝐁𝐄𝐌 𝐕𝐈𝐍𝐃𝐎 (𝐀)💛
└─╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌─┘    

╓╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║⋆💛ׁ͙̟̇𓈒·₊˚𝐔𝐬𝐮𝐚𝐫𝐢𝐨: ${pushname}
║⋆💛ׁ͙̟̇𓈒·₊˚𝐕𝐞𝐫𝐬𝐚̃𝐨: *${botv}*
║⋆💛ׁ͙̟̇𓈒·₊˚𝐁𝐨𝐭: *${NomeDoBot}*  
║⋆💛ׁ͙̟̇𓈒·₊˚𝐏𝐫𝐞𝐦𝐢𝐮𝐦: *${isPremium ? "✓" : "✘"}*  
┗╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯

╓┰╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║┋୨ 💛𝐃❍𝐖𝐍𝐋𝐎𝐀𝐃𝐒💛 ୧
║┣╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯
║┃࣪╭★∻∹⋰⋰ ☆∻∹⋰⋰ ★∻∹⋰⋰
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}play      
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}playmp4   
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}playstore 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}ytsearch  
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}ytmp3     
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}ytmp4     
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}tiktok_audio
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}tiktok_video
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}instagram 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}facebook  
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}imgpralink 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}videopralink 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}kwai_video 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}amazon    
║┖┴◆:*:◇:*:◆:*:◇:*:◆:*:◇:*💛:*
┗─︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪┛`;
};

exports.menudown = menudown;

const menuios = (prefix, isPremium, NomeDoBot, pushname, sender) => {

return `====================
User: ${pushname}
Version: ${botv}
BotName: ${NomeDoBot}
Premium: ${isPremium ? "✓" : "✘"}
====================

💛- ${prefix}Alugar

======== MENUS ========
💛- ${prefix}MenuDono 
  Menu para os Donos.
💛- ${prefix}MenuAdm  
  Menu para os Admin's.
💛- ${prefix}MenuAtivar
  Menu de Ativações Adm/Dono.
💛- ${prefix}MenuPremium 
  Menu para os Vip's.
💛- ${prefix}MenuEffect 
  Menu de Efeitos.
💛- ${prefix}MenuLogos 
  Menu de Logos e Banner's.
💛- ${prefix}MenuAle
  Menu Aleatório.
💛- ${prefix}MenuZoas 
  Menu de Brincadeiras.
💛- ${prefix}MenuRpg  
  Menu de Rpg Supremo.

======= MEMBROS =======
💛- ${prefix}idiomas  
  Listar idiomas disponíveis para o gtts
💛- ${prefix}bug      
  Reportar bugs do bot
💛- ${prefix}sugestao 
  Enviar sugestões para o Dono
💛- ${prefix}avalie   
  Avaliar o bot
💛- ${prefix}moedas   
  Valor das Moedas Atuais
💛- ${prefix}sticker  
  Criar figurinhas
💛- ${prefix}adquirir-key 
  Comprar a chave de API

===== DOWN/PESQ =======
💛- ${prefix}play      
  Baixar música pelo nome YT
💛- ${prefix}playmp4   
  Baixar vídeo pelo nome YT
💛- ${prefix}playstore 
  Pesquisar apps na Play Store via nome
💛- ${prefix}ytsearch  
  Buscar vídeos no YouTube via nome
💛- ${prefix}ytmp3     
  Baixar áudio do YouTube via link
💛- ${prefix}ytmp4     
  Baixar vídeo do YouTube via link
💛- ${prefix}tiktok    
  Baixar vídeos do TikTok via link
💛- ${prefix}instagram 
  Baixar vídeos do Instagram via link
💛- ${prefix}facebook  
  Baixar vídeos do Facebook via link
💛- ${prefix}imgpralink 
  Imagem para o link
💛- ${prefix}videopralink 
  Vídeo para o link
💛- ${prefix}amazon    
  Pesquisar produtos na Amazon

==== INFO/NÍVEL ======
💛- ${prefix}ping      
  Checar latência do bot
💛- ${prefix}docbot   
  Informações do código
💛- ${prefix}atividade 
  Atividade do grupo
💛- ${prefix}rankativo 
  Ranking dos mais ativos do gp
💛- ${prefix}checkativo 
  Checar se o usuário está ativo
💛- ${prefix}ranklevel 
  Ranking por nível

======= JOGOS ========
💛- ${prefix}iniciar_forca 
  Começar jogo da forca
💛- ${prefix}ppt  
  Jogar pedra, papel e tesoura
💛- ${prefix}jogodavelha @
  Jogo da velha
💛- ${prefix}cassino      
  Jogo de cassino virtual

==== FIGU/ATTP =======
💛- ${prefix}attp     
  Texto animado para figurinhas
💛- ${prefix}attp2    
  Outra variação de texto animado
💛- ${prefix}fsticker 
  Fazer figurinhas animadas
💛- ${prefix}sticker  
  Criar figurinhas
💛- ${prefix}toimg    
  Converter figurinha para imagem
💛- ${prefix}togif    
  Converter figurinha para GIF
💛- ${prefix}roubar   
  Roubar figurinha
====================`;
};

exports.menuios = menuios;

const menuhentai = (prefix, isPremium, NomeDoBot, pushname, sender) => {

return `┌─╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌─┐
┊       💛𝐁𝐄𝐌 𝐕𝐈𝐍𝐃𝐎 (𝐀)💛
└─╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌─┘    

╓╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║⋆💛ׁ͙̟̇𓈒·₊˚𝐔𝐬𝐮𝐚𝐫𝐢𝐨: ${pushname}
║⋆💛ׁ͙̟̇𓈒·₊˚𝐕𝐞𝐫𝐬𝐚̃𝐨: *${botv}*
║⋆💛ׁ͙̟̇𓈒·₊˚𝐁𝐨𝐭: *${NomeDoBot}*  
║⋆💛ׁ͙̟̇𓈒·₊˚𝐏𝐫𝐞𝐦𝐢𝐮𝐦: *${isPremium ? "✓" : "✘"}*  
┗╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯

╓┰╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║┋   ୨ 💛𝐇𝐄𝐍𝐓𝐀𝐈'𝐒💛 ୧
║┣╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯
║┃࣪╭★∻∹⋰⋰ ☆∻∹⋰⋰ ★∻∹⋰⋰
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}ass
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}bdsm
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}blowjob
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}boobs
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}gangbang
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}hentai
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}kasedaiki
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}masturbation
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}neko2
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}pussy
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}trap
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}yuri
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}zettai
║┖┴◆:*:◇:*:◆:*:◇:*:◆:*:◇:*💛:*
┗─︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪┛`;
};

exports.menuhentai = menuhentai;

const menunoticias = (prefix, isPremium, NomeDoBot, pushname, sender) => {

return `┌─╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌─┐
┊       💛𝐁𝐄𝐌 𝐕𝐈𝐍𝐃𝐎 (𝐀)💛
└─╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌─┘    

╓╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║⋆💛ׁ͙̟̇𓈒·₊˚𝐔𝐬𝐮𝐚𝐫𝐢𝐨: ${pushname}
║⋆💛ׁ͙̟̇𓈒·₊˚𝐕𝐞𝐫𝐬𝐚̃𝐨: *${botv}*
║⋆💛ׁ͙̟̇𓈒·₊˚𝐁𝐨𝐭: *${NomeDoBot}*  
║⋆💛ׁ͙̟̇𓈒·₊˚𝐏𝐫𝐞𝐦𝐢𝐮𝐦: *${isPremium ? "✓" : "✘"}*  
┗╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯


╓┰╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║┋ ୨ 💛𝐍❍𝐓𝐈𝐂𝐈𝐀'𝐬💛 ୧
║┣╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯
║┃࣪╭★∻∹⋰⋰ ☆∻∹⋰⋰ ★∻∹⋰⋰
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}globo
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}poder360
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}jovempan
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}uol
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}estadao
║┖┴◆:*:◇:*:◆:*:◇:*:◆:*:◇:*💛:*
┗─︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪┛`;
};

exports.menunoticias = menunoticias;

const menumembro = (prefix, isPremium, NomeDoBot, pushname, sender) => {

return `┌─╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌─┐
┊       💛𝐁𝐄𝐌 𝐕𝐈𝐍𝐃𝐎 (𝐀)💛
└─╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌─┘    

╓╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║⋆💛ׁ͙̟̇𓈒·₊˚𝐔𝐬𝐮𝐚𝐫𝐢𝐨: ${pushname}
║⋆💛ׁ͙̟̇𓈒·₊˚𝐕𝐞𝐫𝐬𝐚̃𝐨: *${botv}*
║⋆💛ׁ͙̟̇𓈒·₊˚𝐁𝐨𝐭: *${NomeDoBot}*  
║⋆💛ׁ͙̟̇𓈒·₊˚𝐏𝐫𝐞𝐦𝐢𝐮𝐦: *${isPremium ? "✓" : "✘"}*  
┗╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯


╓┰╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║┋  ୨ 💛𝐌𝐄𝐌𝐁❍𝐒💛 ୧
║┣╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯
║┃࣪╭★∻∹⋰⋰ ☆∻∹⋰⋰ ★∻∹⋰⋰
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}idiomas  
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}bug      
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}sugestao 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}avalie   
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}moedas   
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}sticker  
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}play
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}play2
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}adquirir-key 
║┖┴◆:*:◇:*:◆:*:◇:*:◆:*:◇:*💛:*
┗─︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪┛`;
};

exports.menumembro = menumembro;

const menuanimes = (prefix, isPremium, NomeDoBot, pushname, sender) => {

return `┌─╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌─┐
┊       💛𝐁𝐄𝐌 𝐕𝐈𝐍𝐃𝐎 (𝐀)💛
└─╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌─┘    

╓╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║⋆💛ׁ͙̟̇𓈒·₊˚𝐔𝐬𝐮𝐚𝐫𝐢𝐨: ${pushname}
║⋆💛ׁ͙̟̇𓈒·₊˚𝐕𝐞𝐫𝐬𝐚̃𝐨: *${botv}*
║⋆💛ׁ͙̟̇𓈒·₊˚𝐁𝐨𝐭: *${NomeDoBot}*  
║⋆💛ׁ͙̟̇𓈒·₊˚𝐏𝐫𝐞𝐦𝐢𝐮𝐦: *${isPremium ? "✓" : "✘"}*  
┗╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯


╓┰╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║┋   ୨ 💛𝐀𝐍𝐈𝐌𝐄𝐒💛 ୧
║┣╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯
║┃࣪╭★∻∹⋰⋰ ☆∻∹⋰⋰ ★∻∹⋰⋰
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}anime -cosplay
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}anime -waifu
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}anime -loli
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}anime -shota
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}anime -shinomiya
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}anime -yotsuba
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}anime -yumeko
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}anime -tejina
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}anime -chiho
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}anime -kaori
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}anime -boruto
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}anime -shizuka
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}anime -kaga
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}anime -kotori
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}anime -mikasa
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}anime -akiyama
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}anime -gremory
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}anime -izuku
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}anime -shina
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}anime -shinka
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}anime -yuri
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}anime -eba
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}anime -erza
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}anime -elaina
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}anime -hinata
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}anime -naruto
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}anime -minato
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}anime -sagari
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}anime -nezuko
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}anime -rize
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}anime -anna
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}anime -deidara
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}anime -asuna
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}anime -ayuzawa
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}anime -emilia
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}anime -chitoge
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}anime -hestia
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}anime -inori
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}anime -itachi
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}anime -madara
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}anime -sakura
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}anime -sasuke
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}anime -tsunade
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}anime -onepiece
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}anime -mobil
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}anime -montor
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}anime -keneki
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}anime -megumin
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}anime -toukachan
║┖┴◆:*:◇:*:◆:*:◇:*:◆:*:◇:*💛:*
┗─︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪┛`;
};

exports.menuanimes = menuanimes;

const menucompleto = (prefix, isPremium, NomeDoBot, pushname, sender) => {

return `┌─╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌─┐
┊       💛𝐁𝐄𝐌 𝐕𝐈𝐍𝐃𝐎 (𝐀)💛
└─╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌─┘    

╓╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║⋆💛ׁ͙̟̇𓈒·₊˚𝐔𝐬𝐮𝐚𝐫𝐢𝐨: ${pushname}
║⋆💛ׁ͙̟̇𓈒·₊˚𝐕𝐞𝐫𝐬𝐚̃𝐨: *${botv}*
║⋆💛ׁ͙̟̇𓈒·₊˚𝐁𝐨𝐭: *${NomeDoBot}*  
║⋆💛ׁ͙̟̇𓈒·₊˚𝐏𝐫𝐞𝐦𝐢𝐮𝐦: *${isPremium ? "✓" : "✘"}*  
┗╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯

╓┰╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║┋      ୨ 💛𝐓𝐀𝐊𝐄'𝐬💛 ୧
║┣╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯
║┃࣪╭★∻∹⋰⋰ ☆∻∹⋰⋰ ★∻∹⋰⋰
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}rgtake
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}rntake
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}take
║┖┴◆:*:◇:*:◆:*:◇:*:◆:*:◇:*💛:*
┗─︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪┛

╓┰╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║┋ ୨ 💛𝐃❍𝐖𝐍𝐋𝐎𝐀𝐃𝐒💛 ୧
║┣╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯
║┃࣪╭★∻∹⋰⋰ ☆∻∹⋰⋰ ★∻∹⋰⋰
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}play      
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}playmp4   
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}playstore 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}ytsearch  
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}ytmp3     
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}ytmp4     
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}tiktok    
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}instagram 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}facebook  
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}imgpralink 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}videopralink 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}amazon    
║┖┴◆:*:◇:*:◆:*:◇:*:◆:*:◇:*💛:*
┗─︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪┛

╓┰╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║┋  ୨ 💛𝐍❍𝐓𝐈𝐂𝐈𝐀𝐒💛 ୧
║┣╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯
║┃࣪╭★∻∹⋰⋰ ☆∻∹⋰⋰ ★∻∹⋰⋰
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}globo
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}poder360
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}jovempan
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}uol
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}estadao
║┖┴◆:*:◇:*:◆:*:◇:*:◆:*:◇:*💛:*
┗─︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪┛

╓┰╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║┋ ୨ 💛𝐌𝐄𝐌𝐁𝐑❍𝐒💛 ୧
║┣╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯
║┃࣪╭★∻∹⋰⋰ ☆∻∹⋰⋰ ★∻∹⋰⋰
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}idiomas  
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}bug      
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}sugestao 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}avalie   
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}moedas   
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}sticker  
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}play
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}play2
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}adquirir-key 
║┖┴◆:*:◇:*:◆:*:◇:*:◆:*:◇:*💛:*
┗─︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪┛

╓┰╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╮
║┋  ୨ 💛𝐁𝐀𝐒𝐈𝐂❍𝐒💛 ୧
║┣╌✩̣̣̣̣̣ͯ┄•͙✧┄✩ͯ•͙͙✧•͙͙✩ͯ┄•͙✧•✩͙╌╯
║┃࣪╭★∻∹⋰⋰ ☆∻∹⋰⋰ ★∻∹⋰⋰
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}esporte_noticias 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}celular  
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}gtts 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}tagme
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}emoji
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}emojimix 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}tabela   
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}conselhobiblico  
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}perfil   
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}calcular 
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}fazernick
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}bot  
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}signo
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}metadinha
║┃࣪├̟💛ׁ̇𓈒·₊↬ ${prefix}tomp3   
║┖┴◆:*:◇:*:◆:*:◇:*:◆:*:◇:*💛:*
┗─︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪──๋︩︪┛`;
};

exports.menucompleto = menucompleto;